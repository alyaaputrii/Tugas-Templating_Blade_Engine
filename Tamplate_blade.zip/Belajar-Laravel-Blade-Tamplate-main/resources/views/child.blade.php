{{-- @extends('parent')

@section('title', 'Halaman Utama')
    
@section('header')
    <p>Deskripsi Header</p>
@endsection

@section('content')
    <p>Ini adalah halaman utama</p>
@endsection --}}




{{-- Ini menggunakan template inheritance dan juga section --}}

@extends('parent')

@section('title', 'Halaman Utama')
    
